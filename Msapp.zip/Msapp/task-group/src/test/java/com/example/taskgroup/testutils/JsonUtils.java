package com.example.taskgroup.testutils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.taskgroup.model.Groups;
import com.example.taskgroup.model.Task;
import java.util.*;

import java.io.IOException;

public class JsonUtils {
    public static byte[] toJson(Object object) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        return mapper.writeValueAsBytes(object);
    }
    public static Groups createGroup(int id, String name, String status) {
    	Task task = new Task();
    	task.setId(1);
    	task.setName("Praveen");
    	task.setPriority("1");
    	task.setStartDate("04-Jul-2020");
    	task.setEndDate("08-Jul-2020");
    	task.setStatus("Active");
    	List<Task> list= new ArrayList<Task>();
    	
    	Groups group = new Groups();
    	group.setId(id);
    	group.setName(name);
    	group.setStatus(status);
    	group.setTasks(list);
  	 	return group;
    }
}
